const add = (a, b) => {
  return a + b;
};

const sub = (a, b) => {
  return a - b;
};
const mult = (a, b) => {
  return a * b;
};

const name = "vinod";

// module.exports.add1 = add;
// module.exports.sub1 = sub;
// module.exports.mult1 = mult;

module.exports = { add, sub, mult, name };
