const { add, sub, name, mult } = require("./oper");

console.log(add(5, 5));
console.log(sub(10, 5));
console.log(mult(10, 5));
console.log(name);
